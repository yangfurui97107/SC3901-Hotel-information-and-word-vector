/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import bean.CountryHotel;
import bean.HotelBean;
import bean.ReviewBean;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 *
 * @author Administrator
 */
public class ExcelExporter {

    private HSSFWorkbook workbook;
    private FileInputStream workbookStream = null;

    public ExcelExporter() throws FileNotFoundException, IOException {
        //workbookStream = new FileInputStream("C:\\BookingHotels.xls");
        workbook = new HSSFWorkbook();
    }
    
    public void exportExcelFile(ArrayList<CountryHotel> countryHotelsList) throws FileNotFoundException, IOException{
        for (CountryHotel countryHotel : countryHotelsList) {
            createCountryHotelsSheet(countryHotel);
        }
        FileOutputStream fileOut;
        fileOut = new FileOutputStream(new File("C:\\BookingHotels.xls"));
        workbook.write(fileOut);
        System.out.println("Excel generated successfully");
    }

    public void createCountryHotelsSheet(CountryHotel countryHotel)
    {
        int sheetIndex = workbook.getSheetIndex(countryHotel.getCountryName());
        int rowCounter = 1;
        int serCounter = 1;
        HSSFSheet sheet;
        if (sheetIndex == -1) {
            sheet = workbook.createSheet(countryHotel.getCountryName());
            
            //Header Row
            HSSFRow rowhead = sheet.createRow((short) 0);
            rowhead.createCell(0).setCellValue("Ser No.");
            rowhead.createCell(1).setCellValue("Name");
            rowhead.createCell(2).setCellValue("Review Score");
            rowhead.createCell(3).setCellValue("Review Status");
            rowhead.createCell(4).setCellValue("Sustainability Level");
            rowhead.createCell(5).setCellValue("URL");

            rowhead.createCell(6).setCellValue("Sub Ser.");
            rowhead.createCell(7).setCellValue("Reviewer Name");
            rowhead.createCell(8).setCellValue("Reviewer Country");
            rowhead.createCell(9).setCellValue("Room Type");
            rowhead.createCell(10).setCellValue("Traveller");
            rowhead.createCell(11).setCellValue("Stay Date");
            rowhead.createCell(12).setCellValue("Review Date");
            rowhead.createCell(13).setCellValue("Rating");
            rowhead.createCell(14).setCellValue("Score");
            rowhead.createCell(15).setCellValue("Text");
        } else {
            sheet = workbook.getSheetAt(sheetIndex);
            rowCounter = sheet.getLastRowNum() + 1;
            serCounter = rowCounter;
        }

        if (countryHotel.getHotelsList().size() > 0) {
            for (HotelBean hotelBean : countryHotel.getHotelsList()) {
                if (!hotelBean.getHotelName().equalsIgnoreCase("")) {
                    HSSFRow row = sheet.createRow((short) rowCounter);
                    row.createCell(0).setCellValue(serCounter + "");
                    row.createCell(1).setCellValue(hotelBean.getHotelName());
                    row.createCell(2).setCellValue(hotelBean.getReviewScore());
                    row.createCell(3).setCellValue(hotelBean.getReviewStatus());
                    row.createCell(4).setCellValue(hotelBean.getSustainabilityLevel());
                    row.createCell(5).setCellValue(hotelBean.getHotelURL());
                    rowCounter++;
                    if (hotelBean.getReviewsList().size() > 0) {
                        int reviewCounter = 1;
                        for (ReviewBean reviewBean : hotelBean.getReviewsList()) {
                            if (!reviewBean.getReviewerName().equalsIgnoreCase("")) {
                                HSSFRow reviewRow = sheet.createRow((short) rowCounter);
                                reviewRow.createCell(1).setCellValue(hotelBean.getHotelName());
                                reviewRow.createCell(2).setCellValue(hotelBean.getReviewScore());
                                reviewRow.createCell(3).setCellValue(hotelBean.getReviewStatus());
                                reviewRow.createCell(4).setCellValue(hotelBean.getSustainabilityLevel());
                                reviewRow.createCell(5).setCellValue(hotelBean.getHotelURL());
                                reviewRow.createCell(6).setCellValue("(" + reviewCounter + ")");
                                reviewRow.createCell(7).setCellValue(reviewBean.getReviewerName());
                                reviewRow.createCell(8).setCellValue(reviewBean.getReviewerCountry());
                                reviewRow.createCell(9).setCellValue(reviewBean.getRoomType());
                                reviewRow.createCell(10).setCellValue(reviewBean.getTraveller());
                                reviewRow.createCell(11).setCellValue(reviewBean.getStayDate());
                                reviewRow.createCell(12).setCellValue(reviewBean.getReviewDate());
                                reviewRow.createCell(13).setCellValue(reviewBean.getRatingStatus());
                                reviewRow.createCell(14).setCellValue(reviewBean.getRatingScore());
                                reviewRow.createCell(15).setCellValue(reviewBean.getReviewText());
                                reviewCounter++;
                                rowCounter++;
                            }
                        }
                    }
                    serCounter++;
                }
            }
        }

        
    }
}
