/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Administrator
 */
public class ReviewsPageURLParsing {
    public static ArrayList<String> getReviewsPageURL(String hotelPageURL){
        ArrayList<String> reviewsUrlList = new ArrayList<String>();
        Map urlParamsMap = getQueryMap(hotelPageURL);
        String reviewsURL = "https://www.booking.com/reviewlist.en-gb.html?";
        String aid = (String)urlParamsMap.get("aid");
        reviewsURL+="aid="+aid;
        String label = hotelPageURL.substring(hotelPageURL.indexOf("label="), hotelPageURL.indexOf("&aid"));
        reviewsURL+="&"+label;
        String sid = (String)urlParamsMap.get("sid");
        reviewsURL+="&sid="+sid;
        
        String[] ctyRegionSplit = hotelPageURL.split(".en-gb.html?");
        if(ctyRegionSplit.length > 0){
            String ctyRegion =ctyRegionSplit[0];
            String[] hotelSplit = ctyRegion.split("/");
            if(hotelSplit.length > 0){
                String hotelRegionName = hotelSplit[hotelSplit.length - 2];
                reviewsURL+="&cc1="+hotelRegionName+";dist=1;";
                String hotelPageName = hotelSplit[hotelSplit.length - 1];
                reviewsURL+="pagename="+hotelPageName+";";
            }            
        }
        
        String srpvid = (String)urlParamsMap.get("srpvid");
        reviewsURL+="srpvid="+srpvid+";";       
        String firstPostfixStr = "type=total&&offset=0;rows=25";
        reviewsURL+=firstPostfixStr;
        reviewsUrlList.add(reviewsURL);
        String secondPostfixStr = "type=total&&offset=26;rows=25";
        reviewsURL+=secondPostfixStr;
        reviewsUrlList.add(reviewsURL);
        return reviewsUrlList;
    }
    public static Map<String, String> getQueryMap(String query) {  
        String[] params = query.split("&");  
        Map<String, String> map = new HashMap<String, String>();

    for (String param : params) {  
        String name = param.split("=")[0];  
        String value = param.split("=")[1];  
        map.put(name, value);  
    }  
    return map;  
}
    
    
}
