package parser;

import bean.CountryHotel;
import bean.HotelBean;
import bean.ReviewBean;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebParser {

    public CountryHotel parseExpediaHotelsListPage(String pageURL) {
        CountryHotel countryHotel = new CountryHotel();
        try {
            Document doc = Jsoup.connect(pageURL).timeout(0).validateTLSCertificates(false).userAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36").get();
            Elements countryElements = doc.select("div.uitk-spacing uitk-spacing-margin-blockstart-three");
            if (countryElements.size() > 0) {
                System.out.println(countryElements.text());
            }        
        } catch (Exception e) {
            e.printStackTrace();
        }

        return countryHotel;
    }
    
    public CountryHotel parseHotelsListPage(String pageURL) {
        CountryHotel countryHotel = new CountryHotel();
        try {
            Document doc = Jsoup.connect(pageURL).timeout(0).validateTLSCertificates(false).userAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36").get();
            Elements countryElements = doc.select("input.eb46370fe1");
            if (countryElements.size() > 0) {
                String countryName = countryElements.attr("value");
                System.out.println(countryName);
                countryHotel.setCountryName(countryName);
            }
            Elements hotelElements = doc.select("div.c82435a4b8,div.a178069f51,div.a6ae3c2b40,div.a18aeea94d,div.d794b7a0f7,div.f53e278e95,div.c6710787a4");
            System.out.println(hotelElements.size());
            ArrayList<HotelBean> hotelsList = new ArrayList<HotelBean>();
            if (hotelElements.size() > 0) {
                for (Element hotelElement : hotelElements) {
                    HotelBean hotelBean = new HotelBean();

                    Elements reviewScoreElements = hotelElement.select("div.d86cee9b25");
                    if (reviewScoreElements.size() > 0) {
                        String reviewScore = reviewScoreElements.text();
                        System.out.println("Review Score: " + reviewScore);
                        hotelBean.setReviewScore(reviewScore);
                    }

                    Elements reviewStatusElements = hotelElement.select("div.cb2cbb3ccb");
                    if (reviewStatusElements.size() > 0) {
                        String reviewStatus = reviewStatusElements.text();
                        System.out.println("Review Status: " + reviewStatus);
                        hotelBean.setReviewStatus(reviewStatus);
                    }

                    Elements sustainabilityLevelElements = hotelElement.select("span.f68ecd98ea");
                    if (sustainabilityLevelElements.size() > 0) {
                        String sustainabilityLevel = sustainabilityLevelElements.text();
                        System.out.println("Sustainability Level: " + sustainabilityLevel);
                        hotelBean.setSustainabilityLevel(sustainabilityLevel);
                    }

                    Elements reviewGridElements = hotelElement.select("h3.aab71f8e4e");
                    for (Element reviewGridElement : reviewGridElements) {

                        Elements linkElements = reviewGridElement.select("a[href]");
                        if (linkElements.size() > 0) {
                            Element titleElement = linkElements.get(0).child(0);
                            String hotelName = titleElement.text();
                            System.out.println("Name: " + hotelName);
                            hotelBean.setHotelName(hotelName);

                            String hotelURL = linkElements.attr("href");
                            System.out.println("URL: " + hotelURL);
                            hotelBean.setHotelURL(hotelURL);

                            ArrayList<String> reviewsPageURL = ReviewsPageURLParsing.getReviewsPageURL(hotelURL);
                            for(String reviewPageURL: reviewsPageURL){
                                System.out.println("Review Page: "+reviewPageURL);
                                ArrayList<ReviewBean> reviewsList = parseHotelPage(reviewPageURL);
                                hotelBean.getReviewsList().addAll(reviewsList);
                            }
                            
                        }
                        System.out.println("-----------------------------------------------------");
                    }
                    hotelsList.add(hotelBean);
                }
            }
            countryHotel.setHotelsList(hotelsList);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return countryHotel;
    }

    public ArrayList<ReviewBean> parseHotelPage(String reviewsPageURL) {
        ArrayList<ReviewBean> reviewsList = new ArrayList<ReviewBean>();
        try {
            System.out.println("reviews page parsing");
            Document doc = Jsoup.connect(reviewsPageURL).timeout(0).validateTLSCertificates(false).userAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36").get();
            
            Elements reviewGridElements = doc.select("ul.review_list");
            System.out.println("reviews length = "+reviewGridElements.size());
            if (reviewGridElements.size() > 0) {
                reviewsList = parseReviewPage(reviewGridElements.get(0));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return reviewsList;
    }

    public ArrayList<ReviewBean> parseReviewPage(Element reviewListElem) {
        ArrayList<ReviewBean> reviewsList = new ArrayList<ReviewBean>();
        try {
            Elements reviewGridElements = reviewListElem.select("div.c-review-block");
            System.out.println(reviewGridElements.size());
            if (reviewGridElements.size() > 0) {
                for (Element reviewGridElement : reviewGridElements) {
                    ReviewBean reviewBean = new ReviewBean();

                    Elements titleElements = reviewGridElement.select("span.bui-avatar-block__title");
                    if (titleElements.size() > 0) {
                        String reviewerName = titleElements.text();
                        System.out.println("Name: " + reviewerName);
                        reviewBean.setReviewerName(reviewerName);
                    }

                    Elements countryElements = reviewGridElement.select("span.bui-avatar-block__subtitle");
                    if (countryElements.size() > 0) {
                        String reviewerCountry = countryElements.text();
                        System.out.println("Country: " + reviewerCountry);
                        reviewBean.setReviewerCountry(reviewerCountry);
                    }

                    Elements roomTypeElements = reviewGridElement.select("div.c-review-block__room-info-row");
                    if (roomTypeElements.size() > 0) {
                        String roomType = roomTypeElements.text();
                        System.out.println("Room Type:" + roomType);
                        reviewBean.setRoomType(roomType);
                    }

                    Elements travellerTypeElements = reviewGridElement.select("ul.review-panel-wide__traveller_type");
                    if (travellerTypeElements.size() > 0) {
                        String travellerType = travellerTypeElements.text();
                        System.out.println("Traveller Type:" + travellerType);
                        reviewBean.setTraveller(travellerType);
                    }

                    Elements stayDateElements = reviewGridElement.select("ul.c-review-block__stay-date");
                    if (stayDateElements.size() > 0) {
                        String stayDate = stayDateElements.text();
                        System.out.println("Stay Date:" + stayDate);
                        reviewBean.setStayDate(stayDate);
                    }

                    Elements reviewBlockRightElements = reviewGridElement.select("div.c-review-block__right");
                    if (reviewBlockRightElements.size() > 0) {
                        Elements reviewDateElements = reviewBlockRightElements.select("span.c-review-block__date");
                        if (reviewDateElements.size() > 0) {
                            String reviewDate = reviewDateElements.text();
                            System.out.println("Review Date:" + reviewDate);
                            reviewBean.setReviewDate(reviewDate);
                        }
                    }

                    Elements reviewRatingElements = reviewGridElement.select("h3.c-review__title--ltr");
                    if (reviewRatingElements.size() > 0) {
                        String reviewRating = reviewRatingElements.text();
                        System.out.println("Rating:" + reviewRating);
                        reviewBean.setRatingStatus(reviewRating);
                    }

                    Elements reviewScoreElements = reviewGridElement.select("div.bui-review-score__badge");
                    if (reviewScoreElements.size() > 0) {
                        String reviewScore = reviewScoreElements.text();
                        System.out.println("Score:" + reviewScore);
                        reviewBean.setRatingScore(reviewScore);
                    }

                    Elements reviewTextElements = reviewGridElement.select("span.c-review__body");
                    if (reviewTextElements.size() > 0) {
                        String reviewText = reviewTextElements.text();
                        System.out.println("Text:" + reviewText);
                        reviewBean.setReviewText(reviewText);
                    }

                    System.out.println("-----------------------------------------------------");
                    reviewsList.add(reviewBean);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return reviewsList;
    }

}
