/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Administrator
 */
public class URLParser {

    public static void main(String[] args) {
        String pageURL = "https://www.expedia.com/Bandar-Penawar-Hotels-OneOnly-Desaru-Coast.h38875201.Hotel-Information?chkin=2023-12-12&chkout=2023-12-16&x_pwa=1&rfrr=HSR&pwa_ts=1701842130356&referrerUrl=aHR0cHM6Ly93d3cuZXhwZWRpYS5jb20vSG90ZWwtU2VhcmNo&useRewards=false&rm1=a2&regionId=108&destination=Malaysia&destType=MARKET&latLong=3.151696%2C101.694237&trackingData=AAAAAQAAAAEAAAAQWd4d-_cDd54Hi93L7X-R6nPltPi_HORlLWt-htzPirc-DmOakkL8h1hRIGk7eP_iJsP5rjnnfXJbfXZirqm1GJCcDHUsF7OnqtdvOeExy7GjMQOSWnuBTfTx8YLYegvFX19cK2-UlSdO1NukKbyaQ9a9yDd8lnql-sr8OuRAfLIDdo1vCD9mGnVSbOf3TMj47ib-JaYyUjfsDZaFJNIuiQeTicnBRwfbw8x7OY_HXLP2QgN48iK86aoSxXcKWC4kCu2_g5IG1chZgd4zv2AyF79zektCawT-8uFfwdZOeaFOB2_8ibLmp9mlCHe78RPEhEXWLW6j5b4voysP8mlUFjBQPDMGThKLuqc-q7okyTBa7uYdZX8k91hziW6EscyEQb4UG_Vhxcq9QhWJGN0yoKA2b5AMwLplK4TiO2rCgxcviyz8LGFSnzSjHYnNigxkGNyGcYMXR3-qqHDLIMEqrMLzBgo42ZBCHxCfVBIdhBuEdVWpiiUe0qy-qgUqVkup1xvIGJFE6hME4HBCYBRbNu7yqSTfP1-Wg3WeDSPeynuMh2XgKZn4jCOIGVgN6ohtJTdaW19mds-rhgyHUuVbA5j9tjOFrpJ8SL1qiLwWvwCfSyBtyGLutlsNlZBPsECRqXEXP7vm80VZ0a4yZrvz1Ri-JxL5ce8hS3gChPTAnPe-OAMAzNJ_EFJzntR7jijSQukjpiw48Qn4rTKsxl1fmEBTZceaUB5dGKFKAKV2tN1kbmGuQE_otZ8suNf_oJXMt2aWjMWMQGTpoDFHF-KTwlMsLSWJEwneSfXTf5uAw1vaoC_rdeZwMNWdP8DVXJNJyWs4eTbuiiX-GeAvQZNRH40Qy3L_h_lWIUyc6nptPckk60zk6-cKUrw3FoJMh6vYLFL12yr1-T-jDFdV-HE0niDG4ed53njrZr3ehi2frHKiLa8WKKQgwuR1L2BTA7YScnyHK1Mhbq52g2v9Youy-ph0zHE_VK0CF_-ImeHFX3KSKksiTV0IJ-exdw0t4_yaTuRemwXTCth0DTpuVYfrvfmA_FXxYdunJw_q14Jydah8q1O3sxZ6I1YQVt85m1QhH7U909lUC-Zmd_5Leb0QlNaF5xUVSlXs2_Vmd-ZeyMVxlwMiv245N1OvAeqZNoZ7g6GW8hqDBenJGJ0jTfo6JrHHf3H-egXWLbCIlhukzWfCrnE16xNuPRCS4r2NXNXmSPC-jhIrKiiMI0TprSaNW5XqwfvaKtWupe9_oUvztl0G9rFnc5vnMNCjjMfMz5zBdqMcK9Ji_JGsWsnSRLzs4B8H_E-rpi4ZgnTjlXtjMFPBjpAcvakCfm5FUGBnQZ1i93rB81VhP6fXwBgExSkT1-aXCbybt61hGDeP2VHkws8khxDtc00RNCpSO9Bwzy2-5SXE2SZuGWoQCNP3ulAU2tqp2i_eBeKMaRIKr86b5AuEPnN5N0bT0SnIZOHHTDNA0_DSpU10XSjF2ps-AaNkP_CVIn6V5ZFOE6Xgn2Lu7yPa0U9AXCMOEDiLaAe1l6r7cNOqKoh4gF7ilc0MV7ATOAmO1s2nN2uZzLBYkyLfK741oE1pE60t2E6OinFVG11HBvvovKR6qWRN8dRGB7I4zIoqT5L04JJptA9rs7XsWJAvEnPFCRQWX-qamFIDTElUS_Q1PcL3T-DfxsnglAT14jWH4HCrjRsMrUZ6gMDQJmjcZFkxI2IhwXZ-jh1eRnLbqD2ZvWxTMohBFk7ZTiFN0UELOOno8JNtarXLJGdGHqkq2s9aK6Zeexvvbr9oF4L_V1mmLT5SC3Zi0qSoGsWJeB4OrBjaPV7XZBHhu-DJIHOFs1D7EvarFO8ELJVz0ZKNcaSQ_klAwLF0XaArHySjJ8uSvSBh8MWbjY7l3XIYS--_EdRCyc_c_RnNu0nr-jL4YJwXKWd4rTUPom2ZsEDFpuhTBmjZrrJ0huUeLD8pB2Codg5JehVMLinPdtI1GIHF8IHea-NxNbyAT7pPpmreA8Gd0Aldu36otiiCHP5EZpoOXczzzBqviA46vRK-ktq-&rank=1&testVersionOverride=Buttercup%2C39483.0.0%2C47230.158373.1%2C49619.150273.0%2C48676.160236.2%2C48304.159182.1%2C50206.153476.0%2C50028.155516.0%2C50782.0.0%2C50813.156505.0%2C49817.159756.1%2C50988.158353.0%2C47890.143201.1&slots=&position=1&beaconIssued=&sort=RECOMMENDED&top_dp=579&top_cur=USD&userIntent=&selectedRoomType=218162176&selectedRatePlan=391259637&searchId=a4119c1b-f37f-459c-95c6-e9040c5dea30";
        System.out.println(pageURL);
        System.out.println("---------------------");
        String reviewURL = "https://www.expedia.com/Bandar-Penawar-Hotels-OneOnly-Desaru-Coast.h38875201.Hotel-Information?beaconIssued=&chkin=2023-12-12&chkout=2023-12-16&destType=MARKET&destination=Malaysia&latLong=3.151696%2C101.694237&position=1&pwaDialog=sui-see-all-reviews-dialog&pwa_ts=1701842130356&rank=1&referrerUrl=aHR0cHM6Ly93d3cuZXhwZWRpYS5jb20vSG90ZWwtU2VhcmNo&regionId=108&rfrr=HSR&rm1=a2&searchId=a4119c1b-f37f-459c-95c6-e9040c5dea30&selectedRatePlan=391259637&selectedRoomType=218162176&slots=&sort=RECOMMENDED&testVersionOverride=Buttercup%2C39483.0.0%2C47230.158373.1%2C49619.150273.0%2C48676.160236.2%2C48304.159182.1%2C50206.153476.0%2C50028.155516.0%2C50782.0.0%2C50813.156505.0%2C49817.159756.1%2C50988.158353.0%2C47890.143201.1&top_cur=USD&top_dp=579&trackingData=AAAAAQAAAAEAAAAQWd4d-_cDd54Hi93L7X-R6nPltPi_HORlLWt-htzPirc-DmOakkL8h1hRIGk7eP_iJsP5rjnnfXJbfXZirqm1GJCcDHUsF7OnqtdvOeExy7GjMQOSWnuBTfTx8YLYegvFX19cK2-UlSdO1NukKbyaQ9a9yDd8lnql-sr8OuRAfLIDdo1vCD9mGnVSbOf3TMj47ib-JaYyUjfsDZaFJNIuiQeTicnBRwfbw8x7OY_HXLP2QgN48iK86aoSxXcKWC4kCu2_g5IG1chZgd4zv2AyF79zektCawT-8uFfwdZOeaFOB2_8ibLmp9mlCHe78RPEhEXWLW6j5b4voysP8mlUFjBQPDMGThKLuqc-q7okyTBa7uYdZX8k91hziW6EscyEQb4UG_Vhxcq9QhWJGN0yoKA2b5AMwLplK4TiO2rCgxcviyz8LGFSnzSjHYnNigxkGNyGcYMXR3-qqHDLIMEqrMLzBgo42ZBCHxCfVBIdhBuEdVWpiiUe0qy-qgUqVkup1xvIGJFE6hME4HBCYBRbNu7yqSTfP1-Wg3WeDSPeynuMh2XgKZn4jCOIGVgN6ohtJTdaW19mds-rhgyHUuVbA5j9tjOFrpJ8SL1qiLwWvwCfSyBtyGLutlsNlZBPsECRqXEXP7vm80VZ0a4yZrvz1Ri-JxL5ce8hS3gChPTAnPe-OAMAzNJ_EFJzntR7jijSQukjpiw48Qn4rTKsxl1fmEBTZceaUB5dGKFKAKV2tN1kbmGuQE_otZ8suNf_oJXMt2aWjMWMQGTpoDFHF-KTwlMsLSWJEwneSfXTf5uAw1vaoC_rdeZwMNWdP8DVXJNJyWs4eTbuiiX-GeAvQZNRH40Qy3L_h_lWIUyc6nptPckk60zk6-cKUrw3FoJMh6vYLFL12yr1-T-jDFdV-HE0niDG4ed53njrZr3ehi2frHKiLa8WKKQgwuR1L2BTA7YScnyHK1Mhbq52g2v9Youy-ph0zHE_VK0CF_-ImeHFX3KSKksiTV0IJ-exdw0t4_yaTuRemwXTCth0DTpuVYfrvfmA_FXxYdunJw_q14Jydah8q1O3sxZ6I1YQVt85m1QhH7U909lUC-Zmd_5Leb0QlNaF5xUVSlXs2_Vmd-ZeyMVxlwMiv245N1OvAeqZNoZ7g6GW8hqDBenJGJ0jTfo6JrHHf3H-egXWLbCIlhukzWfCrnE16xNuPRCS4r2NXNXmSPC-jhIrKiiMI0TprSaNW5XqwfvaKtWupe9_oUvztl0G9rFnc5vnMNCjjMfMz5zBdqMcK9Ji_JGsWsnSRLzs4B8H_E-rpi4ZgnTjlXtjMFPBjpAcvakCfm5FUGBnQZ1i93rB81VhP6fXwBgExSkT1-aXCbybt61hGDeP2VHkws8khxDtc00RNCpSO9Bwzy2-5SXE2SZuGWoQCNP3ulAU2tqp2i_eBeKMaRIKr86b5AuEPnN5N0bT0SnIZOHHTDNA0_DSpU10XSjF2ps-AaNkP_CVIn6V5ZFOE6Xgn2Lu7yPa0U9AXCMOEDiLaAe1l6r7cNOqKoh4gF7ilc0MV7ATOAmO1s2nN2uZzLBYkyLfK741oE1pE60t2E6OinFVG11HBvvovKR6qWRN8dRGB7I4zIoqT5L04JJptA9rs7XsWJAvEnPFCRQWX-qamFIDTElUS_Q1PcL3T-DfxsnglAT14jWH4HCrjRsMrUZ6gMDQJmjcZFkxI2IhwXZ-jh1eRnLbqD2ZvWxTMohBFk7ZTiFN0UELOOno8JNtarXLJGdGHqkq2s9aK6Zeexvvbr9oF4L_V1mmLT5SC3Zi0qSoGsWJeB4OrBjaPV7XZBHhu-DJIHOFs1D7EvarFO8ELJVz0ZKNcaSQ_klAwLF0XaArHySjJ8uSvSBh8MWbjY7l3XIYS--_EdRCyc_c_RnNu0nr-jL4YJwXKWd4rTUPom2ZsEDFpuhTBmjZrrJ0huUeLD8pB2Codg5JehVMLinPdtI1GIHF8IHea-NxNbyAT7pPpmreA8Gd0Aldu36otiiCHP5EZpoOXczzzBqviA46vRK-ktq-&useRewards=false&userIntent=&x_pwa=1";
        System.out.println(reviewURL);
        System.out.println("---------------------");

        String[] pageUrlParts = pageURL.split("\\?");
        String rootPart = pageUrlParts[0] + "?";

        System.out.println("---------------------");
        Map urlParamsMap = getQueryMap(pageURL);
        /*
        String chkin = (String)urlParamsMap.get("chkin");
        rootPart+="chkin="+chkin;
        String chkout = (String)urlParamsMap.get("chkout");
        rootPart+="chkout="+chkout;
         */

        pageURL+="&pwaDialog=sui-see-all-reviews-dialog";
        System.out.println("---------------------");
        //getQueryMap(reviewURL);     

        //iterateUsingLambda(urlParamsMap);
    }

    public static void iterateUsingLambda(Map<String, String> map) {
        map.forEach((key, value) -> {
            System.out.println("Key=" + key + ", Value=" + value);
        });
    }

    public static Map<String, String> getQueryMap(String query) {
        String[] params = query.split("&");
        Map<String, String> map = new HashMap<String, String>();

        for (String param : params) {
            String[] paramParts = param.split("=");
            if (paramParts.length == 2) {
                String name = param.split("=")[0];
                String value = param.split("=")[1];
                map.put(name, value);
                System.out.println(name + "=" + value);
            } else {
                System.out.println(param);
            }

        }
        return map;
    }

}
