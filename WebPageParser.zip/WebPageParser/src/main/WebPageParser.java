/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.ArrayList;
import parser.WebParser;
import bean.CountryHotel;
import java.io.IOException;
import parser.ExcelExporter;

/**
 *
 * @author Sahil
 */
public class WebPageParser {

    private static final WebParser webParser = new WebParser();
    private static final ArrayList<String> countriesHotelsList = new ArrayList<String>();
    private static final ArrayList<CountryHotel> countryHotelsList = new ArrayList<CountryHotel>();
    private static ExcelExporter excelExporter;

    public static void main(String[] args) throws IOException {
        parseAndExportCountryWiseHotels();
    }

    public static void parseAndExportCountryWiseHotels() throws IOException {
        //Japan
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=106&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=106&dest_type=country&nflt=ht_id%3D204&offset=25");

        //Malaysia
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=128&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=128&dest_type=country&nflt=ht_id%3D204&offset=25");

        //China
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=44&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=44&dest_type=country&nflt=ht_id%3D204&offset=25");

        //Indonesia
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=99&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=99&dest_type=country&nflt=ht_id%3D204&offset=25");

        //France
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=73&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=73&dest_type=country&nflt=ht_id%3D204&offset=25");

        //UK
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=222&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=222&dest_type=country&nflt=ht_id%3D204&offset=25");

        //Germany
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=80&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=80&dest_type=country&nflt=ht_id%3D204&offset=25");

        //Italy
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=104&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=104&dest_type=country&nflt=ht_id%3D204&offset=25");

        //Singapore
        countriesHotelsList.add("https://www.booking.com/searchresults.html?aid=304142&label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=190&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?aid=304142&label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=190&dest_type=country&nflt=ht_id%3D204&offset=25");

        //USA
        countriesHotelsList.add("https://www.booking.com/searchresults.html?aid=304142&label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=224&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.html?aid=304142&label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAExuAEXyAEM2AEB6AEB-AECiAIBqAIDuALnzbqrBsACAdICJDdkMWEzMzk4LTk0ZTAtNGZhOS1iZDdkLThkMzQ2MmE0M2RhNNgCBeACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=224&dest_type=country&nflt=ht_id%3D204&offset=25");

        //Thailand
        countriesHotelsList.add("https://www.booking.com/searchresults.en-gb.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAEJuAEXyAEM2AEB6AEB-AELiAIBqAIDuAKyt8WrBsACAdICJDllNjNhNGQxLTE2M2ItNGQyOS05Y2VkLTM5MDVkNzU3ZWIyOdgCBuACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=209&dest_type=country&nflt=ht_id%3D204");
        countriesHotelsList.add("https://www.booking.com/searchresults.en-gb.html?label=gen173nr-1FCAEoggI46AdIM1gEaLUBiAEBmAEJuAEXyAEM2AEB6AEB-AELiAIBqAIDuAKyt8WrBsACAdICJDllNjNhNGQxLTE2M2ItNGQyOS05Y2VkLTM5MDVkNzU3ZWIyOdgCBuACAQ&sid=86f20dce1fc1895b240c6af27d50ba33&dest_id=209&dest_type=country&nflt=ht_id%3D204&offset=25");

        scrapWebPages();        
        exportExcel();
    }

    public static void scrapWebPages() {
        for (String countryURL : countriesHotelsList) {
            CountryHotel countryHotel = webParser.parseHotelsListPage(countryURL);
            countryHotelsList.add(countryHotel);
        }        
    }
    
    public static void exportExcel() throws IOException {
        if (countryHotelsList.size() > 0) {
            excelExporter.exportExcelFile(countryHotelsList);
        }
    }
}
