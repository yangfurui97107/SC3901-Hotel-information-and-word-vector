/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class CountryHotel {
    private String countryName;
    private ArrayList<HotelBean> hotelsList;

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public ArrayList<HotelBean> getHotelsList() {
        return hotelsList;
    }

    public void setHotelsList(ArrayList<HotelBean> hotelsList) {
        this.hotelsList = hotelsList;
    }
}
