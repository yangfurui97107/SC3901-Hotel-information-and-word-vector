/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class HotelBean {
    private String hotelName = "";
    private String hotelURL = "";
    private String reviewScore = "";
    private String reviewStatus = "";
    private String sustainabilityLevel = "";
    private ArrayList<ReviewBean> reviewsList = new ArrayList<ReviewBean>();

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public String getHotelURL() {
        return hotelURL;
    }

    public void setHotelURL(String hotelURL) {
        this.hotelURL = hotelURL;
    }

    public String getReviewScore() {
        return reviewScore;
    }

    public void setReviewScore(String reviewScore) {
        this.reviewScore = reviewScore;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getSustainabilityLevel() {
        return sustainabilityLevel;
    }

    public void setSustainabilityLevel(String sustainabilityLevel) {
        this.sustainabilityLevel = sustainabilityLevel;
    }

    public ArrayList<ReviewBean> getReviewsList() {
        return reviewsList;
    }

    public void setReviewsList(ArrayList<ReviewBean> reviewsList) {
        this.reviewsList = reviewsList;
    }
    
}
